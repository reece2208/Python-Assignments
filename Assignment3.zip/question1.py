y=eval(input("Enter the height of the rectangle:\n"))
x=eval(input("Enter the width of the rectangle:\n"))

def rectangle(x,y):
            for j in range(0,y,1):
                        print(x*"*")
            
rectangle(x,y)
    

